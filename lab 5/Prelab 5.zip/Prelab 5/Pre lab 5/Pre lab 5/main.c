/*
 * NombreProgra.c
 *
 * Created: 
 * Author: 
 * Description: 
 */
/****************************************/
// Encabezado (Libraries)



#include <avr/io.h>
#include <avr/interrupt.h>
#include "Libreria_ADC.h"
#include "PWM_init.h"

uint8_t ADC_lecture = 0;
uint8_t servo_OCR0A = 0;



/****************************************/
// Function prototypes

void setup();
//void TMR0_init_PWM (uint16_t prescaler);
//void TMR1_init_PWM(uint16_t prescaler, uint16_t ICR1_value);


/****************************************/
// Main Function

int main(void)
{
	
	setup();
	
	while (1)
	{
		 ADC_lecture = ADC_canal(7);
		 
		 if (ADC_lecture >= 120 && ADC_lecture <= 135)
		 {
			 servo_OCR0A = 23; // ANCHO: 1.5ms = Detener servo
			 
		 } else if (ADC_lecture < 120)
		 {
			 
			 servo_OCR0A = 16; // ANCH0: 1ms = CW move
			 
		 } else {
			 servo_OCR0A = 31; // ANCHO: 2ms = CCW move
		 }
		 
		 OCR0A = servo_OCR0A;
		
	}
}

/****************************************/
// NON-Interrupt subroutines


void setup(){
	
	cli();
		
	//Registros DDRn
	
	DDRC = 0x00; // Declarar puerto C como entrada.
	
	TMR0_init_PWM(1024); // Periodo de 16ms
	//TMR1_init_PWM(1024, 312); //Periodo de 20ms
	
	ADC_init(); // Inicializar el ADC. Sin seleccionar el canal
	

		
	
	sei();
}



/****************************************/
// Interrupt routines